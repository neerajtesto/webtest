particlesJS.load('particles-display','particlesjs-config.json',()=>{
        console.log('particles loaded successfully :)')
    });
var button_no=1;
var disp_para_id="about";
display_info(1);

function revert_button(x){
button_id="ji_button_"+x;	
button=document.getElementById(button_id);
button.style.backgroundColor="black";
button.style.color="chartreuse";
button.style.border="double purple 3px";
}

function revert_para(id){
	document.getElementById(id).style.display="none";
}

function display_info(x){
 revert_button(button_no);	
 revert_para(disp_para_id);
 button_id="ji_button_"+x;
 button_no=x;
 button=document.getElementById(button_id);
 button.style.backgroundColor="white";
 button.style.color="black";
 button.style.border="double green 3px";
 id="";
 switch(x){
	case 1:
      id="about";
	  break;
    case 2:
	  id="career";
	  break;
	case 3:
	  id="awards";
	  break;	
 }
 disp_para_id=id;
 document.getElementById(id).style.display="block";
}
